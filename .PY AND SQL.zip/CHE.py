user_data={}
def sign_up():
    print("===== Sign Up =====")
    name = input("Enter your name: ")
    email = input("Enter your email: ")
    contact = input("Enter your contact number: ")
    location = input("Enter your location: ")
    user_data[email] = {
        "name": name,
        "contact": contact,
        "location": location
    }
    print("Sign up successful!\n")

def sign_in():
    print("===== Sign In =====")
    email = input("Enter your email: ")
    if email in user_data:
        print("Welcome back, {}! Your details are as follows:".format(user_data[email]['name']))
        print("Name: {}".format(user_data[email]['name']))
        print("Email: {}".format(email))
        print("Contact: {}".format(user_data[email]['contact']))
        print("Location: {}".format(user_data[email]['location']))
    else:
        print("User not found. Please sign up first.\n")

# Main program loop
while True:
    print("===== Air Pollution Program =====")
    print("1. Sign Up")
    print("2. Sign In")
    print("3. Exit")
    choice = input("Enter your choice (1/2/3): ")

    if choice == '1':
        sign_up()
    elif choice == '2':
        sign_in()
    elif choice =='3':
        print("Exiting the program.")
        break
    else:
        print("Invalid choice. Please try again.\n")
    break
import mysql.connector
# Database connection parameters
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'kailey181',
    'database': 'pollution'
}

# Function to check AQI for a specific location
def check_aqi(location):
    try:
        # Establish database connection
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        # SQL query to retrieve AQI data for a specific location
        query = "SELECT aqi_value FROM air_quality WHERE location = %s ORDER BY timestamp DESC LIMIT 1"
        cursor.execute(query, (location,))
        
        # Fetch the latest AQI value for the location
        result = cursor.fetchone()

        if result:
            aqi_value = result[0]
            print(f"AQI value for {location}: {aqi_value}")

            # Check if AQI value exceeds the threshold
            if aqi_value > 100:
                print("AQI exceeds 100. Air quality is unhealthy.")
                print("Preventive measures for elevated air quality (AQI > 100):")
                print("1. Limit outdoor activities, especially for sensitive groups like children and the elderly.")
                print("2. Use masks or face coverings to reduce inhalation of pollutants.")
                print("3. Avoid strenuous exercises outdoors.")
                print("4. Keep windows and doors closed to prevent outdoor air from entering.")
                print("5. Use air purifiers indoors to filter pollutants.")
                print("6. Stay informed about air quality updates and forecasts.")
                print("7. Reduce vehicular activities and carpool when possible.")

# Example usage
            else:
                print("AQI is within safe limits. Air quality is good.")
                print("Preventive measures for good air quality (AQI < 100):")
                print("1. Enjoy outdoor activities and exercise.")
                print("2. Open windows and doors to allow fresh air circulation.")
                print("3. Promote sustainable practices like reducing vehicle emissions.")
                print("4. Support local initiatives for green spaces and tree planting.")
                print("5. Keep indoor spaces well-ventilated.")
                print("6. Use air purifiers to maintain indoor air quality.")
                print("7. Stay informed about air quality trends and forecasts.")
        else:
            print(f"No AQI data found for {location}")

    except Exception as e:
        print(f"Error: {e}")

    finally:
        # Close database connection
        if connection.is_connected():
            cursor.close()
            connection.close()

# Example usage
location = input("Enter location to check AQI: ")
check_aqi(location)
user_data = {}

